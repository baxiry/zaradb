import os, sys

while True:
	os.system("./multi tes")
