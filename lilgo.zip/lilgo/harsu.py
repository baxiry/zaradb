import os, sys

while True:
	os.system("./shan harsu")
